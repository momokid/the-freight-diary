<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('kaina', function (Blueprint $table) {
            $table->tinyInteger('must_change_password')->default(0)->after('reset_requested');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('kaina', function (Blueprint $table) {
            $table->dropColumn('must_change_password');
        });
    }
};
