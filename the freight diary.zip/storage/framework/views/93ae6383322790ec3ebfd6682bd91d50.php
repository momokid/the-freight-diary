<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo e($reportTitle); ?></title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #111827;
            background: #fff;
            padding: 24px;
        }

        .action-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: flex-end;
        }

        .btn-print {
            padding: 8px 20px;
            background: #185FA5;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-export {
            padding: 8px 20px;
            background: #15803d;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }

        .rpt-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding-bottom: 14px;
            border-bottom: 3px solid #185FA5;
            margin-bottom: 16px;
        }

        .rpt-logo-block {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .rpt-logo {
            height: 56px;
            width: auto;
        }

        .rpt-company-name {
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 3px;
        }

        .rpt-company-sub {
            font-size: 10px;
            color: #6b7280;
            line-height: 1.7;
        }

        .rpt-meta-block {
            text-align: right;
        }

        .rpt-title {
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .rpt-meta-row {
            font-size: 10px;
            color: #6b7280;
            line-height: 1.9;
        }

        .rpt-meta-val {
            font-weight: 600;
            color: #111827;
        }

        /* Account cards */
        .account-block {
            margin-bottom: 20px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
        }

        .account-header {
            background: #185FA5;
            color: #fff;
            padding: 10px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .account-name {
            font-size: 13px;
            font-weight: 700;
        }

        .balance-badges {
            display: flex;
            gap: 10px;
        }

        .badge-item {
            text-align: right;
        }

        .badge-label {
            font-size: 9px;
            color: #bfdbfe;
        }

        .badge-val {
            font-size: 13px;
            font-weight: 700;
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }

        thead th {
            background: #f3f4f6;
            color: #374151;
            padding: 7px 12px;
            text-align: left;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            border-bottom: 1px solid #e5e7eb;
        }

        thead th.r {
            text-align: right;
        }

        tbody td {
            padding: 7px 12px;
            border-bottom: 1px solid #f3f4f6;
            font-size: 12px;
        }

        tbody td.r {
            text-align: right;
        }

        .no-tx {
            padding: 12px;
            text-align: center;
            color: #9ca3af;
            font-size: 12px;
            font-style: italic;
        }

        /* Summary grid */
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-bottom: 16px;
        }

        .summary-card {
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 10px 12px;
            text-align: center;
        }

        .s-label {
            font-size: 9px;
            text-transform: uppercase;
            color: #6b7280;
            margin-bottom: 4px;
        }

        .s-val {
            font-size: 16px;
            font-weight: 700;
        }

        .rpt-footer {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            font-size: 9px;
            color: #9ca3af;
        }

        @media print {
            .action-bar {
                display: none;
            }

            body {
                padding: 12px;
            }
        }
    </style>
</head>

<body>

    <div class="action-bar">
        <button class="btn-export" onclick="window.exportReport()">Export to Excel</button>
        <button class="btn-print" onclick="window.print()">Print</button>
    </div>

    <div class="rpt-header">
        <div class="rpt-logo-block">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e($company?->InstName ?? 'PSIL'); ?>" class="rpt-logo"
                onerror="this.style.display='none'">
            <div>
                <p class="rpt-company-name"><?php echo e($company?->InstName ?? 'Prime Survivors International Ltd'); ?></p>
                <p class="rpt-company-sub"><?php echo e($company?->Address ?? ''); ?><br>
                    <?php if($company?->TelNo): ?>
                        Tel: <?php echo e($company->TelNo); ?>

                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="rpt-meta-block">
            <p class="rpt-title"><?php echo e($reportTitle); ?></p>
            <p class="rpt-meta-row">Date &nbsp;<span class="rpt-meta-val"><?php echo e($dateFormatted); ?></span></p>
            <p class="rpt-meta-row">Branch &nbsp;<span
                    class="rpt-meta-val"><?php echo e($branchID === 'ALL' ? 'All Branches' : $branchID); ?></span></p>
            <p class="rpt-meta-row">Generated &nbsp;<span
                    class="rpt-meta-val"><?php echo e(now()->format('d M Y, h:i A')); ?></span></p>
            <p class="rpt-meta-row">By &nbsp;<span
                    class="rpt-meta-val"><?php echo e(auth()->user()->FullName ?? auth()->user()->ID); ?></span></p>
        </div>
    </div>

    
    <div class="summary-grid">
        <div class="summary-card">
            <div class="s-label">Accounts</div>
            <div class="s-val" style="color:#185FA5;"><?php echo e(count($accounts)); ?></div>
        </div>
        <div class="summary-card">
            <div class="s-label">Total Opening</div>
            <div class="s-val" style="font-size:13px;">GH₵ <?php echo e(number_format($accounts->sum('OpeningBalance'), 2)); ?>

            </div>
        </div>
        <div class="summary-card">
            <div class="s-label">Total Movements</div>
            <div class="s-val" style="font-size:13px; color:#185FA5;">
                <?php echo e($accounts->sum(fn($a) => $a->Transactions->count())); ?> txn(s)
            </div>
        </div>
        <div class="summary-card">
            <div class="s-label">Total Closing</div>
            <div class="s-val" style="font-size:13px;">GH₵ <?php echo e(number_format($accounts->sum('ClosingBalance'), 2)); ?>

            </div>
        </div>
    </div>

    
    <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="account-block">
            <div class="account-header">
                <span class="account-name"><?php echo e($account->AccountName); ?></span>
                <div class="balance-badges">
                    <div class="badge-item">
                        <div class="badge-label">Opening</div>
                        <div class="badge-val">GH₵ <?php echo e(number_format($account->OpeningBalance, 2)); ?></div>
                    </div>
                    <div class="badge-item">
                        <div class="badge-label">Dr Today</div>
                        <div class="badge-val">GH₵ <?php echo e(number_format($account->TodayDr, 2)); ?></div>
                    </div>
                    <div class="badge-item">
                        <div class="badge-label">Cr Today</div>
                        <div class="badge-val">GH₵ <?php echo e(number_format($account->TodayCr, 2)); ?></div>
                    </div>
                    <div class="badge-item">
                        <div class="badge-label">Closing</div>
                        <div class="badge-val"
                            style="color:<?php echo e($account->ClosingBalance >= 0 ? '#bbf7d0' : '#fecaca'); ?>">
                            GH₵ <?php echo e(number_format($account->ClosingBalance, 2)); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php if($account->Transactions->count() > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th style="width:10%">Time</th>
                            <th style="width:14%">Receipt No</th>
                            <th style="width:36%">Description</th>
                            <th style="width:10%">Mode</th>
                            <th class="r" style="width:15%">Dr (GH₵)</th>
                            <th class="r" style="width:15%">Cr (GH₵)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $account->Transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="color:#6b7280; font-family:monospace;">
                                    <?php echo e(\Carbon\Carbon::parse($tx->Time)->format('h:i A')); ?>

                                </td>
                                <td style="font-family:monospace;"><?php echo e($tx->ReceiptNo ?? '—'); ?></td>
                                <td><?php echo e($tx->Description ?? '—'); ?></td>
                                <td>
                                    <span
                                        style="display:inline-block; font-size:10px; font-weight:700; padding:2px 8px; border-radius:99px; background:<?php echo e($tx->Mode === 'Dr' ? '#fef3c7' : '#dcfce7'); ?>; color:<?php echo e($tx->Mode === 'Dr' ? '#92400e' : '#166534'); ?>">
                                        <?php echo e($tx->Mode); ?>

                                    </span>
                                </td>
                                <td class="r" style="color:#b91c1c;"><?php echo e(number_format($tx->Dr, 2)); ?></td>
                                <td class="r" style="color:#15803d;"><?php echo e(number_format($tx->Cr, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-tx">No transactions on this date</div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p style="text-align:center;padding:2rem;color:#9ca3af;">No active bank/cash accounts found.</p>
    <?php endif; ?>

    <div class="rpt-footer">
        <span>The Freight Diary &nbsp;·&nbsp; <?php echo e($company?->InstName ?? 'Prime Survivors International Ltd'); ?>

            &nbsp;·&nbsp; Confidential</span>
        <span>Printed by: <?php echo e(auth()->user()->FullName ?? auth()->user()->ID); ?> &nbsp;·&nbsp;
            <?php echo e(now()->format('d M Y, h:i A')); ?></span>
    </div>

    <script>
        window.exportReport = function() {
            const params = new URLSearchParams(window.location.search);
            window.location.href = '<?php echo e(route('reports.accounting.daily-balance.export')); ?>?' + params.toString();
        };
    </script>
</body>

</html>
<?php /**PATH E:\Project\the-freight-app\resources\views/reports/accounting/daily-balance-print.blade.php ENDPATH**/ ?>