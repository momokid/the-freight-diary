<?php $__env->startSection('title', 'Operations Reports'); ?>

<?php $__env->startSection('content'); ?>

    <div style="display:flex; flex-direction:column; gap:1.25rem;">

        <div>
            <h1 class="page-title">Operations Reports</h1>
            <p style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">System Reports &rsaquo; Operations</p>
        </div>

        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:1.25rem; align-items:flex-start;">
            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        CONSIGNMENT STATUS SUMMARY
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="ss_date_from" class="form-input">
                    <input type="date" id="ss_date_to" class="form-input">
                    <select id="ss_status" class="form-input">
                        <option value="all">All Statuses</option>
                        <option value="1">Not Arrived</option>
                        <option value="2">Pending</option>
                        <option value="3">Gated Out</option>
                        <option value="0">Cleared</option>
                    </select>
                    <p id="ss_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewConsignmentStatus()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        CONSIGNMENT DETAIL REPORT
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="cd_date_from" class="form-input">
                    <input type="date" id="cd_date_to" class="form-input">
                    <select id="cd_status" class="form-input">
                        <option value="all">All Statuses</option>
                        <option value="1">Not Arrived</option>
                        <option value="2">Pending</option>
                        <option value="3">Gated Out</option>
                        <option value="0">Cleared</option>
                    </select>
                    <p id="cd_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewConsignmentDetail()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        CONSIGNMENT CARRIER REPORT
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="cc_date_from" class="form-input" onchange="window.loadCarriers()">
                    <input type="date" id="cc_date_to" class="form-input" onchange="window.loadCarriers()">
                    <select id="cc_carrier" class="form-input">
                        <option value="">Loading carriers...</option>
                    </select>
                    <p id="cc_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewConsignmentCarrier()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        PORT AGING REPORT
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="pa_date_from" class="form-input">
                    <input type="date" id="pa_date_to" class="form-input">
                    <select id="pa_status" class="form-input">
                        <option value="all">All Statuses</option>
                        <option value="1">Not Arrived</option>
                        <option value="2">Pending</option>
                        <option value="3">Gated Out</option>
                        <option value="0">Cleared</option>
                    </select>
                    <p id="pa_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewPortAging()" class="btn-primary" style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        PENDING CLEARANCE REPORT
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="pc_date_from" class="form-input">
                    <input type="date" id="pc_date_to" class="form-input">
                    <select id="pc_status" class="form-input">
                        <option value="all">All Statuses</option>
                        <option value="1">Not Arrived</option>
                        <option value="2">Pending</option>
                        <option value="3">Gated Out</option>
                        <option value="0">Cleared</option>
                    </select>
                    <p id="pc_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewPendingClearance()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        CONSIGNMENT VOLUME REPORT
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="cv_date_from" class="form-input">
                    <input type="date" id="cv_date_to" class="form-input">
                    <p id="cv_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewConsignmentVolume()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        GATE-OUT REGISTER
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="go_date_from" class="form-input">
                    <input type="date" id="go_date_to" class="form-input">
                    <select id="go_status" class="form-input">
                        <option value="all">All</option>
                        <option value="gatedout">Gated Out (Outstanding)</option>
                        <option value="returned">Returned</option>
                    </select>
                    <p id="go_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewGateOutRegister()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

            
            <div class="card" style="padding:0;">
                <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-color);">
                    <p style="font-size:0.8rem; font-weight:700; color:#185FA5; letter-spacing:0.04em;">
                        CLEARANCE PERFORMANCE REPORT
                    </p>
                </div>
                <div style="padding:1.25rem; display:flex; flex-direction:column; gap:0.75rem;">
                    <input type="date" id="cp_date_from" class="form-input"
                        onchange="window.loadClearanceCarriers()">
                    <input type="date" id="cp_date_to" class="form-input" onchange="window.loadClearanceCarriers()">
                    <select id="cp_carrier" class="form-input">
                        <option value="">All Carriers</option>
                    </select>
                    <p id="cp_error" style="display:none; font-size:0.75rem; color:#b91c1c; text-align:center;"></p>
                    <button onclick="window.viewClearancePerformance()" class="btn-primary"
                        style="width:100%; margin-top:0.25rem;">
                        View Report
                    </button>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // ── Route config ─────────────────────────────────────────────────────────
        window.ConsignmentStatusReport = {
            printUrl: '<?php echo e(route('reports.operations.consignment-status.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.consignment-status.export')); ?>',
        };

        window.ConsignmentDetailReport = {
            printUrl: '<?php echo e(route('reports.operations.consignment-detail.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.consignment-detail.export')); ?>',
        };

        window.ConsignmentCarrierReport = {
            printUrl: '<?php echo e(route('reports.operations.consignment-carrier.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.consignment-carrier.export')); ?>',
            carriersUrl: '<?php echo e(route('reports.operations.consignment-carrier.carriers')); ?>',
        };

        window.PortAgingReport = {
            printUrl: '<?php echo e(route('reports.operations.port-aging.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.port-aging.export')); ?>',
        };

        window.PendingClearanceReport = {
            printUrl: '<?php echo e(route('reports.operations.pending-clearance.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.pending-clearance.export')); ?>',
        };

        window.ConsignmentVolumeReport = {
            printUrl: '<?php echo e(route('reports.operations.consignment-volume.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.consignment-volume.export')); ?>',
        };

        window.GateOutRegisterReport = {
            printUrl: '<?php echo e(route('reports.operations.gate-out-register.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.gate-out-register.export')); ?>',
        };

        window.ClearancePerformanceReport = {
            printUrl: '<?php echo e(route('reports.operations.clearance-performance.print')); ?>',
            exportUrl: '<?php echo e(route('reports.operations.clearance-performance.export')); ?>',
            carriersUrl: '<?php echo e(route('reports.operations.consignment-carrier.carriers')); ?>',
        };
        // ── Card 1: Consignment Status Summary ───────────────────────────────────
        window.viewConsignmentStatus = function() {
            const dateFrom = document.getElementById('ss_date_from').value;
            const dateTo = document.getElementById('ss_date_to').value;
            const status = document.getElementById('ss_status').value;

            const ssErr = document.getElementById('ss_error');
            if (!dateFrom || !dateTo) {
                ssErr.textContent = 'Please select both Date From and Date To.';
                ssErr.style.display = 'block';
                return;
            }
            ssErr.style.display = 'none';

            window.open(
                window.ConsignmentStatusReport.printUrl + '?' +
                new URLSearchParams({
                    date_from: dateFrom,
                    date_to: dateTo,
                    status
                }),
                '_blank'
            );
        };

        // ── Card 2: Consignment Detail Report ────────────────────────────────────
        window.viewConsignmentDetail = function() {
            const dateFrom = document.getElementById('cd_date_from').value;
            const dateTo = document.getElementById('cd_date_to').value;
            const status = document.getElementById('cd_status').value;

            const cdErr = document.getElementById('cd_error');
            if (!dateFrom || !dateTo) {
                cdErr.textContent = 'Please select both Date From and Date To.';
                cdErr.style.display = 'block';
                return;
            }
            cdErr.style.display = 'none';

            window.open(
                window.ConsignmentDetailReport.printUrl + '?' +
                new URLSearchParams({
                    date_from: dateFrom,
                    date_to: dateTo,
                    status
                }),
                '_blank'
            );
        };

        // ── Card 3: Consignment Carrier Report ───────────────────────────────────
        window.viewConsignmentCarrier = function() {
            const dateFrom = document.getElementById('cc_date_from').value;
            const dateTo = document.getElementById('cc_date_to').value;
            const carrierId = document.getElementById('cc_carrier').value;

            const ccErr = document.getElementById('cc_error');
            if (!dateFrom || !dateTo) {
                ccErr.textContent = 'Please select both Date From and Date To.';
                ccErr.style.display = 'block';
                return;
            }
            ccErr.style.display = 'none';

            const params = {
                date_from: dateFrom,
                date_to: dateTo
            };
            if (carrierId) params.carrier_id = carrierId;

            window.open(
                window.ConsignmentCarrierReport.printUrl + '?' +
                new URLSearchParams(params),
                '_blank'
            );
        };

        // ── Card 4: Port Aging Report ─────────────────────────────────────────────
        window.viewPortAging = function() {
            const dateFrom = document.getElementById('pa_date_from').value;
            const dateTo = document.getElementById('pa_date_to').value;
            const status = document.getElementById('pa_status').value;
            const paErr = document.getElementById('pa_error');

            if (!dateFrom || !dateTo) {
                paErr.textContent = 'Please select both Date From and Date To.';
                paErr.style.display = 'block';
                return;
            }

            paErr.style.display = 'none';

            window.open(
                window.PortAgingReport.printUrl + '?' +
                new URLSearchParams({
                    date_from: dateFrom,
                    date_to: dateTo,
                    status
                }),
                '_blank'
            );
        };

        // ── Card 5: Pending Clearance Report ─────────────────────────────────────
        window.viewPendingClearance = function() {
            const dateFrom = document.getElementById('pc_date_from').value;
            const dateTo = document.getElementById('pc_date_to').value;
            const status = document.getElementById('pc_status').value;
            const pcErr = document.getElementById('pc_error');

            if (!dateFrom || !dateTo) {
                pcErr.textContent = 'Please select both Date From and Date To.';
                pcErr.style.display = 'block';
                return;
            }

            pcErr.style.display = 'none';

            window.open(
                window.PendingClearanceReport.printUrl + '?' +
                new URLSearchParams({
                    date_from: dateFrom,
                    date_to: dateTo,
                    status
                }),
                '_blank'
            );
        };

        // ── Card 6: Consignment Volume Report ────────────────────────────────────
        window.viewConsignmentVolume = function() {
            const dateFrom = document.getElementById('cv_date_from').value;
            const dateTo = document.getElementById('cv_date_to').value;
            const cvErr = document.getElementById('cv_error');

            if (!dateFrom || !dateTo) {
                cvErr.textContent = 'Please select both Date From and Date To.';
                cvErr.style.display = 'block';
                return;
            }

            cvErr.style.display = 'none';

            window.open(
                window.ConsignmentVolumeReport.printUrl + '?' +
                new URLSearchParams({
                    date_from: dateFrom,
                    date_to: dateTo
                }),
                '_blank'
            );
        };

        // ── Card 7: Gate-Out Register ─────────────────────────────────────────────
        window.viewGateOutRegister = function() {
            const dateFrom = document.getElementById('go_date_from').value;
            const dateTo = document.getElementById('go_date_to').value;
            const status = document.getElementById('go_status').value;
            const goErr = document.getElementById('go_error');

            if (!dateFrom || !dateTo) {
                goErr.textContent = 'Please select both Date From and Date To.';
                goErr.style.display = 'block';
                return;
            }

            goErr.style.display = 'none';

            window.open(
                window.GateOutRegisterReport.printUrl + '?' +
                new URLSearchParams({
                    date_from: dateFrom,
                    date_to: dateTo,
                    status
                }),
                '_blank'
            );
        };

        // ── Card 8: Clearance Performance Report ──────────────────────────────────
        window.viewClearancePerformance = function() {
            const dateFrom = document.getElementById('cp_date_from').value;
            const dateTo = document.getElementById('cp_date_to').value;
            const carrierId = document.getElementById('cp_carrier').value;
            const cpErr = document.getElementById('cp_error');

            if (!dateFrom || !dateTo) {
                cpErr.textContent = 'Please select both Date From and Date To.';
                cpErr.style.display = 'block';
                return;
            }

            cpErr.style.display = 'none';

            const params = {
                date_from: dateFrom,
                date_to: dateTo
            };
            if (carrierId) params.carrier_id = carrierId;

            window.open(
                window.ClearancePerformanceReport.printUrl + '?' +
                new URLSearchParams(params),
                '_blank'
            );
        };

        // Loads carriers filtered by selected date range — reuses carrierList endpoint
        window.loadClearanceCarriers = function() {
            const dateFrom = document.getElementById('cp_date_from').value;
            const dateTo = document.getElementById('cp_date_to').value;
            const sel = document.getElementById('cp_carrier');

            if (!dateFrom || !dateTo) return;

            sel.innerHTML = '<option value="">Loading...</option>';

            fetch(window.ClearancePerformanceReport.carriersUrl + '?' +
                    new URLSearchParams({
                        date_from: dateFrom,
                        date_to: dateTo
                    }), {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                .then(res => res.json())
                .then(data => {
                    sel.innerHTML = '<option value="">All Carriers</option>';
                    if (data.length === 0) {
                        sel.innerHTML = '<option value="">No carriers found</option>';
                        return;
                    }
                    data.forEach(function(c) {
                        const opt = document.createElement('option');
                        opt.value = c.CarrierID;
                        opt.textContent = c.CarrierName;
                        sel.appendChild(opt);
                    });
                })
                .catch(function() {
                    sel.innerHTML = '<option value="">All Carriers</option>';
                });
        };



        // ── Load carriers based on selected dates ────────────────────────────────
        // Fires when either date changes — only fetches if both dates are filled.
        window.loadCarriers = function() {
            const dateFrom = document.getElementById('cc_date_from').value;
            const dateTo = document.getElementById('cc_date_to').value;
            const sel = document.getElementById('cc_carrier');

            if (!dateFrom || !dateTo) return;

            sel.innerHTML = '<option value="">Loading...</option>';

            fetch(window.ConsignmentCarrierReport.carriersUrl + '?' +
                    new URLSearchParams({
                        date_from: dateFrom,
                        date_to: dateTo
                    }), {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                .then(res => res.json())
                .then(data => {
                    sel.innerHTML = '<option value="">All Carriers</option>';
                    if (data.length === 0) {
                        sel.innerHTML = '<option value="">No carriers found</option>';
                        return;
                    }
                    data.forEach(function(c) {
                        const opt = document.createElement('option');
                        opt.value = c.CarrierID;
                        opt.textContent = c.CarrierName;
                        sel.appendChild(opt);
                    });
                })
                .catch(function() {
                    sel.innerHTML = '<option value="">All Carriers</option>';
                });
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project\the-freight-app\resources\views/reports/operations/consignment-status.blade.php ENDPATH**/ ?>