<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Freight Diary | Intelligent Logistics Platform</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <style>
        body {
            background-color: #0a1f13;
            background-image: radial-gradient(rgba(255,255,255,0.03) 1px, transparent 1px);
            background-size: 28px 28px;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center px-4">

    <div class="w-full max-w-md">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html><?php /**PATH E:\Project\the-freight-app\resources\views/layouts/auth.blade.php ENDPATH**/ ?>