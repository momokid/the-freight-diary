<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo e($reportTitle); ?></title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #111827;
            background: #fff;
            padding: 24px;
        }

        .action-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: flex-end;
        }

        .btn-print {
            padding: 8px 20px;
            background: #185FA5;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-export {
            padding: 8px 20px;
            background: #15803d;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }

        .rpt-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding-bottom: 14px;
            border-bottom: 3px solid #185FA5;
            margin-bottom: 16px;
        }

        .rpt-logo-block {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .rpt-logo {
            height: 56px;
            width: auto;
        }

        .rpt-company-name {
            font-size: 14px;
            font-weight: 700;
            color: #111827;
            margin-bottom: 3px;
        }

        .rpt-company-sub {
            font-size: 10px;
            color: #6b7280;
            line-height: 1.7;
        }

        .rpt-meta-block {
            text-align: right;
        }

        .rpt-title {
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .rpt-meta-row {
            font-size: 10px;
            color: #6b7280;
            line-height: 1.9;
        }

        .rpt-meta-val {
            font-weight: 600;
            color: #111827;
        }

        .summary-strip {
            display: flex;
            gap: 10px;
            margin-bottom: 16px;
        }

        .stat-card {
            flex: 1;
            border-radius: 6px;
            padding: 10px 12px;
            border: 1px solid #e5e7eb;
        }

        .stat-label {
            font-size: 9px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #6b7280;
            margin-bottom: 4px;
        }

        .stat-val {
            font-size: 16px;
            font-weight: 700;
            color: #111827;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }

        thead th {
            background: #185FA5;
            color: #fff;
            padding: 8px 10px;
            text-align: left;
            font-size: 11px;
            font-weight: 700;
        }

        thead th.r {
            text-align: right;
        }

        tbody td {
            padding: 7px 10px;
            border-bottom: 1px solid #e5e7eb;
            font-size: 13px;
        }

        tbody td.r {
            text-align: right;
        }

        tbody tr:nth-child(even) td {
            background: #f9fafb;
        }

        .opening-row td,
        .closing-row td {
            background: #eff6ff !important;
            font-weight: 700;
        }

        tfoot td {
            padding: 8px 10px;
            font-weight: 700;
            font-size: 13px;
            background: #f3f4f6;
            border-top: 2px solid #185FA5;
        }

        tfoot td.r {
            text-align: right;
        }

        .bal-pos {
            color: #15803d;
            font-weight: 700;
        }

        .bal-neg {
            color: #b91c1c;
            font-weight: 700;
        }

        .rpt-footer {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            font-size: 9px;
            color: #9ca3af;
        }

        @media print {
            .action-bar {
                display: none;
            }

            body {
                padding: 12px;
            }
        }
    </style>
</head>

<body>

    <div class="action-bar">
        <button class="btn-export" onclick="window.exportReport()">Export to Excel</button>
        <button class="btn-print" onclick="window.print()">Print</button>
    </div>

    <div class="rpt-header">
        <div class="rpt-logo-block">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e($company?->InstName ?? 'PSIL'); ?>" class="rpt-logo"
                onerror="this.style.display='none'">
            <div>
                <p class="rpt-company-name"><?php echo e($company?->InstName ?? 'Prime Survivors International Ltd'); ?></p>
                <p class="rpt-company-sub"><?php echo e($company?->Address ?? ''); ?><br>
                    <?php if($company?->TelNo): ?>
                        Tel: <?php echo e($company->TelNo); ?>

                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="rpt-meta-block">
            <p class="rpt-title"><?php echo e($reportTitle); ?></p>
            <p class="rpt-meta-row">Period &nbsp;<span class="rpt-meta-val"><?php echo e($dateFrom); ?> —
                    <?php echo e($dateTo); ?></span></p>
            <p class="rpt-meta-row">Branch &nbsp;<span
                    class="rpt-meta-val"><?php echo e($branchID === 'ALL' ? 'All Branches' : $branchID); ?></span></p>
            <p class="rpt-meta-row">Generated &nbsp;<span
                    class="rpt-meta-val"><?php echo e(now()->format('d M Y, h:i A')); ?></span></p>
            <p class="rpt-meta-row">By &nbsp;<span
                    class="rpt-meta-val"><?php echo e(auth()->user()->FullName ?? auth()->user()->ID); ?></span></p>
        </div>
    </div>

    <div class="summary-strip">
        <div class="stat-card">
            <div class="stat-label">Account</div>
            <div class="stat-val" style="font-size:13px;"><?php echo e($data['account']?->AccountName ?? '—'); ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Opening Balance</div>
            <div class="stat-val <?php echo e($data['openingBalance'] >= 0 ? 'bal-pos' : 'bal-neg'); ?>">
                GH₵ <?php echo e(number_format($data['openingBalance'], 2)); ?>

            </div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Dr</div>
            <div class="stat-val">GH₵ <?php echo e(number_format($data['totalDr'], 2)); ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Cr</div>
            <div class="stat-val">GH₵ <?php echo e(number_format($data['totalCr'], 2)); ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Closing Balance</div>
            <div class="stat-val <?php echo e($data['closingBalance'] >= 0 ? 'bal-pos' : 'bal-neg'); ?>">
                GH₵ <?php echo e(number_format($data['closingBalance'], 2)); ?>

            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width:10%">Date</th>
                <th style="width:13%">Receipt No</th>
                <th style="width:24%">Description</th>
                <th style="width:18%">Sub Account</th>
                <th class="r" style="width:12%">Dr (GH₵)</th>
                <th class="r" style="width:12%">Cr (GH₵)</th>
                <th class="r" style="width:11%">Balance (GH₵)</th>
            </tr>
        </thead>
        <tbody>
            <tr class="opening-row">
                <td colspan="6" style="font-style:italic;">Opening Balance</td>
                <td class="r <?php echo e($data['openingBalance'] >= 0 ? 'bal-pos' : 'bal-neg'); ?>">
                    <?php echo e(number_format($data['openingBalance'], 2)); ?>

                </td>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $data['transactions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($tx->Date)->format('d M Y')); ?></td>
                    <td style="font-family:monospace"><?php echo e($tx->ReceiptNo ?? '—'); ?></td>
                    <td><?php echo e($tx->Description ?? '—'); ?></td>
                    <td><?php echo e($tx->SubAccountName ?? '—'); ?></td>
                    <td class="r" style="color:#b91c1c;"><?php echo e(number_format($tx->Dr, 2)); ?></td>
                    <td class="r" style="color:#185FA5;"><?php echo e(number_format($tx->Cr, 2)); ?></td>
                    <td class="r <?php echo e($tx->RunningBalance >= 0 ? 'bal-pos' : 'bal-neg'); ?>">
                        <?php echo e(number_format($tx->RunningBalance, 2)); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" style="text-align:center;padding:2rem;color:#9ca3af;">No transactions in this
                        period.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" style="font-weight:700;">Closing Balance</td>
                <td class="r" style="color:#b91c1c;">GH₵ <?php echo e(number_format($data['totalDr'], 2)); ?></td>
                <td class="r" style="color:#185FA5;">GH₵ <?php echo e(number_format($data['totalCr'], 2)); ?></td>
                <td class="r <?php echo e($data['closingBalance'] >= 0 ? 'bal-pos' : 'bal-neg'); ?>">
                    GH₵ <?php echo e(number_format($data['closingBalance'], 2)); ?>

                </td>
            </tr>
        </tfoot>
    </table>

    <div class="rpt-footer">
        <span>The Freight Diary &nbsp;·&nbsp; <?php echo e($company?->InstName ?? 'Prime Survivors International Ltd'); ?>

            &nbsp;·&nbsp; Confidential</span>
        <span>Printed by: <?php echo e(auth()->user()->FullName ?? auth()->user()->ID); ?> &nbsp;·&nbsp;
            <?php echo e(now()->format('d M Y, h:i A')); ?></span>
    </div>

    <script>
        window.exportReport = function() {
            const params = new URLSearchParams(window.location.search);
            window.location.href = '<?php echo e(route('reports.accounting.gl-statement.export')); ?>?' + params.toString();
        };
    </script>
</body>

</html>
<?php /**PATH E:\Project\the-freight-app\resources\views/reports/accounting/gl-statement-print.blade.php ENDPATH**/ ?>